// import 'package:soja/screens/authenticate/sign_in.dart';
// import 'package:test/test.dart';
//
// void main() {
//   test('get email', () {
//     SignIn signIn = new SignIn();
//     var expected = 'b2477332@ben.edu';
//     expect(expected, signIn.getEmail());
//   });
//
//   test('get password', () {
//     SignIn signIn = new SignIn();
//     var expected = 'Yourmom14';
//     expect(expected, signIn.getPassword());
//   });
// }