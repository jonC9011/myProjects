// import 'package:soja/screens/authenticate/register.dart';
// import 'package:test/test.dart';
//
// void main() {
//   test('get email', () {
//     Register register = new Register();
//     var expected = 'b2477332@ben.edu';
//     expect(expected, register.getEmail());
//   });
//
//   test('get username', () {
//     Register register = new Register();
//     var expected = 'b2477332';
//     expect(expected, register.getUsername());
//   });
//
//   test('get first name', () {
//     Register register = new Register();
//     var expected = 'Omer';
//     expect(expected, register.getFirstName());
//   });
//
//   test('get last name', () {
//     Register register = new Register();
//     var expected = 'Bebo';
//     expect(expected, register.getLastName());
//   });
//
//   test('get date', () {
//     Register register = new Register();
//     var expected = '01/19/2000';
//     expect(expected, register.getDate());
//   });
//
//   test('get gender', () {
//     Register register = new Register();
//     var expected = 'Male';
//     expect(expected, register.getGender());
//   });
//
//   test('get password', () {
//     Register register = new Register();
//     var expected = 'Yourmom14';
//     expect(expected, register.getPassword());
//   });
// }