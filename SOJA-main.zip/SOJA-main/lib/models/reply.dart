class Reply {
  static const UID = "uid";
  static const COMMENT = "comment";

  String uid;
  String comment;

  Reply(this.uid, this.comment);
}