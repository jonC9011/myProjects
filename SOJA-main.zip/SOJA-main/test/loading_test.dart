/*

testWidgets('Should parse load sketch.json', (WidgetTester tester) async {
    var loaderFuture = new Loader();

    Future<String> resultFuture = loaderFuture.load();

    resultFuture.then((value) => print(value))
        .catchError((error) => print(error));

    while(true){};
  });

  */